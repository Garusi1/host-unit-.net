﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace PL
//{
//    enum mainMenuEnum //מסך פתיחה
//    {
//        Exit,Add_Guest_Request,Hosting_Unit_Menu,WebManager
//    }

//    enum HostingUnitMenuEnum 
//    {
//        Exit, Add_Hosting_Unit, Personal_Area
//    }

//    enum PersoanlAreaEnum
//    {
//        Exit, Update_Hosting_Unit, Delete_Hosting_Unit,Orders_Menu
//    }

//    enum ManagMenuEnum
//    {
//        Exit,
//        Queries_For_Customer_List, //4.1
//        Queries_For_HostingUnit_List, //4.2
//        Queries_For_Order_List,//4.3
//        Additional_Queries//4.4
//    }

//    enum OrdersMenuEnum //3.0
//    {
//        Exit,
//        Queries_For_Customer_List, //4.1
//        Orders_List //3.4

//    }
//}
